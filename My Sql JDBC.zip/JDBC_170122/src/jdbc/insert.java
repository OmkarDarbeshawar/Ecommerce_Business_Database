package jdbc;

import java.sql.Connection;          //Insert Query
import java.sql.DriverManager;
import java.sql.Statement;

public class insert
{
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		//String sql2="insert into student values('1','abc','punepune')";
		//String sql2="insert into student values('2','abc','punepune')";
		//String sql2="insert into student values('3','mmm','katraj')";
		//String sql2="insert into student values('4','abc','punepune')";
		String sql2="insert into student values('6','XCXCX','Jodgavhan')";
		

	    
		
	    
		
		Statement smt=con.createStatement();
		smt.execute(sql2);
		
		
		smt.close();
		con.close();
		System.out.println("Save Data");
		
		
		
	}

}
