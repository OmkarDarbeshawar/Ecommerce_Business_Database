package jdbc;

import java.sql.Connection;        //     Update Query
import java.sql.DriverManager;
import java.sql.Statement;

public class update
{
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		String sql2="update student set name='Poonam',addr='GGOOAA' where rollno='6'";
		
	    Statement smt=con.createStatement();
		smt.execute(sql2);
		
		
		smt.close();
		con.close();
		System.out.println("Save Data");
		
		
		
	}
}


