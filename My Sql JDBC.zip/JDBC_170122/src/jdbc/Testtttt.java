package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Testtttt 
 {
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		int rno=Integer.parseInt(args[0]);
		String nm=args[1];
		String addr=args[2];
		String sql="insert into student values('"+rno+"','"+nm+"','"+addr+"')";
		
		Statement smt=con.createStatement();
	       smt.execute(sql);
	       smt.close();
			con.close();
		System.out.println("Save Data");
			
			
			
		}

	}

