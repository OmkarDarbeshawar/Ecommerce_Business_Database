//package jdbc;
//
//import java.util.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//import com.mysql.jdbc.ResultSet;
//import com.mysql.jdbc.Statement;
//
//
//public class SelectData
//{
//	public static void main(String[] args) 
//	{
//   try 
//      {
//	   Class.forName("com.mysql.jdbc.Driver");
//	   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
//     String sql="select* from student";
//     Statement smt=con.createStatement();
//     ResultSet rs=smt.executeQuery(sql);
//      
//     
//     while(rs.next())
//       {
//    	 System.out.println(rs.getInt("rollno"));
//    	 System.out.println(rs.getString(2));
//    	 System.out.println(rs.getString(3));
//       }
//      }
//
//	}
//}
//     