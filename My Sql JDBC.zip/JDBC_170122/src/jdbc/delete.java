package jdbc;

import java.sql.Connection;         //Delete Query
import java.sql.DriverManager;
import java.sql.Statement;

public class delete
{
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		
		String sql2="delete from student where rollno='5'";
		

	    
		
	    
		
		Statement smt=con.createStatement();
		smt.execute(sql2);
		
		
		smt.close();
		con.close();
		System.out.println("Save Data");
		
		
		
	}

}
