package jdbc;

import java.sql.Connection;        //only inser coloum
import java.sql.DriverManager;
import java.sql.Statement;

public class Test 
 {
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		int rno=Integer.parseInt(args[0]);
		String nm=args[1];
		String addr=args[2];
		String sql="insert into student values('"+rno+"','"+nm+"','"+addr+"')";
		
		Statement smt=con.createStatement();
	       smt.execute(sql);
	       smt.close();
			con.close();
		System.out.println("Save Data");
	  }

  }




/*package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Test 
{
	public static void main(String[] args) throws Exception 
	 {
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		//String sql="create table student(rollno int NOT NULL PRIMARY KEY,name varchar(25),addr varchar(25))";
		//String sql1="create table student(rollno Int(3),name varchar(25),addr varchar(25))";
		
		//String sql2="insert into student values('1','xyz','karvenagar')";
	    //String sql3="insert into student values('2','abc','pune')"; 
		//String sql4="insert into student values('3','aabbcc','chakan')";
		//String sql5="insert into student values('4','cccc','katraja')";
	    //String sql6="insert into student values('5','ddd','washim')";
		//String sql7="insert into student values('6','ppp','torna')";
		
	    
		
	    
		int rno=Integer.parseInt(args[0]);
		String nm=args[1];
		String addr=args[2];
		String sql="insert into student values('"+rno+"','"+nm+"','"+addr+"')";
		
		Statement smt=con.createStatement();
	       smt.execute(sql);
	       //smt.execute(sql7);
		//smt.execute(sql2);
		//smt.execute(sql3);
		//smt.execute(sql4);
		//smt.execute(sql5);
		//smt.execute(sql);
		
		smt.close();
		con.close();
	System.out.println("Save Data");
		
		
		
	}

}*/
